# Enterprise-Search-Engine-ONGC

# SCREENSHOTS
MAIN SCREEN:


![Screenshot (9)](https://github.com/YashTariyal/Enterprise-Search-Engine-ONGC/blob/main/img/Screenshot%20(212).png)

![Screenshot (9)](https://github.com/YashTariyal/Enterprise-Search-Engine-ONGC/blob/main/img/Screenshot%20(213).png)

![Screenshot (9)](https://github.com/YashTariyal/Enterprise-Search-Engine-ONGC/blob/main/img/Screenshot%20(214).png)

![Screenshot (9)](https://github.com/YashTariyal/Enterprise-Search-Engine-ONGC/blob/main/img/Screenshot%20(215).png)

![Screenshot (9)](https://github.com/YashTariyal/Enterprise-Search-Engine-ONGC/blob/main/img/Screenshot%20(216).png)

![Screenshot (9)](https://github.com/YashTariyal/Enterprise-Search-Engine-ONGC/blob/main/img/Screenshot%20(217).png)
